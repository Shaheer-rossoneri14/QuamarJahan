(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.parallax').parallax();
    $(".dropdown-trigger").dropdown();

  }); // end of document ready
})(jQuery); // end of jQuery name space
